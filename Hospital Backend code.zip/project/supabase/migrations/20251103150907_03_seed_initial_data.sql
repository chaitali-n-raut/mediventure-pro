/*
  # Seed Initial Data for MediVenture Pro

  ## Overview
  Populates the database with sample departments, lab tests, and pharmacy items
  to make the system functional for development and testing.

  ## Data Included
  1. Medical departments (Cardiology, Neurology, etc.)
  2. Common lab tests with pricing
  3. Sample pharmacy items
*/

-- Insert Departments
INSERT INTO departments (name, description, icon) VALUES
  ('Cardiology', 'Heart and cardiovascular health', 'Heart'),
  ('Neurology', 'Brain and nervous system disorders', 'Brain'),
  ('Orthopedics', 'Bone, joint, and muscle care', 'Bone'),
  ('Pediatrics', 'Children''s healthcare', 'Baby'),
  ('Gynecology', 'Women''s reproductive health', 'User'),
  ('General Practice', 'Primary healthcare and general medical services', 'Stethoscope'),
  ('Dermatology', 'Skin health and diseases', 'Zap'),
  ('Oncology', 'Cancer treatment and care', 'AlertTriangle')
ON CONFLICT (name) DO NOTHING;

-- Insert Lab Tests
INSERT INTO lab_tests (name, description, price, normal_range, unit, turnaround_days) VALUES
  ('Complete Blood Count (CBC)', 'Measures red cells, white cells, and hemoglobin', 500, 'WBC: 4.5-11.0', 'K/uL', 1),
  ('Lipid Profile', 'Checks cholesterol and triglyceride levels', 800, 'Total: <200', 'mg/dL', 1),
  ('Blood Sugar (Fasting)', 'Measures glucose level after fasting', 300, '70-100', 'mg/dL', 1),
  ('Thyroid Function Test (TSH)', 'Checks thyroid hormone levels', 600, '0.4-4.0', 'mIU/L', 2),
  ('Liver Function Test', 'Evaluates liver health', 900, 'ALT: 7-56', 'U/L', 1),
  ('Kidney Function Test', 'Assesses kidney health', 850, 'Creatinine: 0.7-1.3', 'mg/dL', 1),
  ('Vitamin B12 Level', 'Checks B12 deficiency', 700, '>200', 'pg/mL', 2),
  ('COVID-19 RT-PCR', 'Detects SARS-CoV-2 virus', 1200, 'Negative', '', 1),
  ('Electrocardiogram (ECG)', 'Records heart electrical activity', 400, 'Normal', '', 1),
  ('Ultrasound Abdomen', 'Imaging of abdominal organs', 2000, 'Normal', '', 1)
ON CONFLICT (name) DO NOTHING;

-- Insert Pharmacy Items
INSERT INTO pharmacy_items (name, description, price, stock_quantity, dosage, manufacturer, expiry_date) VALUES
  ('Aspirin 500mg', 'Pain reliever and blood thinner', 50, 500, '500mg tablet', 'Bayer', '2025-12-31'),
  ('Paracetamol 650mg', 'Fever and pain relief', 40, 1000, '650mg tablet', 'GSK', '2025-12-31'),
  ('Amoxicillin 500mg', 'Antibiotic for bacterial infections', 150, 300, '500mg capsule', 'Sandoz', '2025-12-31'),
  ('Metformin 500mg', 'Diabetes management', 80, 600, '500mg tablet', 'Cipla', '2025-12-31'),
  ('Lisinopril 10mg', 'Blood pressure control', 120, 400, '10mg tablet', 'Novartis', '2025-12-31'),
  ('Omeprazole 20mg', 'Acid reflux treatment', 100, 350, '20mg capsule', 'AstraZeneca', '2025-12-31'),
  ('Vitamin D3 2000IU', 'Calcium absorption support', 200, 800, '2000IU tablet', 'Nature Made', '2025-12-31'),
  ('Iron Supplement 325mg', 'Anemia treatment', 90, 400, '325mg tablet', 'Ferrous', '2025-12-31'),
  ('Cough Syrup', 'Relief from cough and cold', 150, 200, '5ml', 'Robitussin', '2025-12-31'),
  ('Antibiotic Ointment', 'Topical infection prevention', 250, 150, 'Tube 30g', 'Neosporin', '2025-12-31')
ON CONFLICT (name) DO NOTHING;
