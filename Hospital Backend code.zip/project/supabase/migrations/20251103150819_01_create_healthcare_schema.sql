/*
  # MediVenture Pro Healthcare Management System Schema

  ## Overview
  This migration creates the complete database schema for a healthcare management platform supporting patients, doctors, staff, appointments, lab tests, pharmacy, and billing.

  ## 1. New Tables

  ### Core User Tables
  - `user_profiles`: Extended user information beyond auth.users
    - Stores role, full_name, phone, avatar_url
    - Links to auth.users via user_id
  
  - `doctors`: Doctor-specific information
    - Stores specialization, license_number, bio, experience_years
    - Links to user_profiles

  - `departments`: Medical departments
    - Stores name, description, icon
    - Used for organizing doctors and services

  ### Appointment & Scheduling
  - `appointments`: Patient-doctor appointment bookings
    - Status tracking: pending, confirmed, completed, cancelled
    - Includes reason, notes, appointment_date, time_slot
    - Links patient and doctor

  - `appointment_slots`: Available time slots for doctors
    - Date-based slots with available count
    - Links to doctors

  ### Medical Services
  - `lab_tests`: Laboratory test offerings
    - Stores test name, description, price, normal_range

  - `lab_results`: Patient lab test results
    - Stores test_id, patient_id, result_value, notes
    - Status: pending, completed

  - `pharmacy_items`: Pharmacy medicine/product catalog
    - Stores name, description, price, stock_quantity

  - `prescriptions`: Doctor-prescribed medications
    - Links doctor, patient, pharmacy_item
    - Stores quantity and dosage instructions

  ### Billing & Payments
  - `billing_records`: Payment tracking
    - Service type, amount, status (pending, paid, failed)
    - Links to appointments, lab_results, prescriptions
    - Stripe integration ready

  ### Emergency & Support
  - `emergency_contacts`: Emergency contact information
    - Links to patient profiles

  - `support_tickets`: Customer support system
    - Status tracking: open, in_progress, resolved

  ## 2. Security
  - Row Level Security (RLS) enabled on all tables
  - Comprehensive policies for role-based access control
  - Patient data only visible to patient, assigned doctor, and staff
  - Doctor data restricted appropriately
  - Admin/staff access for management functions

  ## 3. Important Notes
  - All timestamps use UTC (timestamptz)
  - Foreign keys cascade appropriately for data integrity
  - Indexes created on frequently queried columns for performance
  - Soft deletes not used; permanent deletes allowed for clean data
*/

-- Create ENUM types for role-based access
CREATE TYPE user_role AS ENUM ('patient', 'doctor', 'staff', 'admin');
CREATE TYPE appointment_status AS ENUM ('pending', 'confirmed', 'completed', 'cancelled');
CREATE TYPE lab_result_status AS ENUM ('pending', 'completed');
CREATE TYPE billing_status AS ENUM ('pending', 'paid', 'failed');
CREATE TYPE support_status AS ENUM ('open', 'in_progress', 'resolved');

-- User Profiles Table
CREATE TABLE IF NOT EXISTS user_profiles (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL UNIQUE REFERENCES auth.users(id) ON DELETE CASCADE,
  role user_role NOT NULL,
  full_name TEXT NOT NULL,
  phone TEXT,
  avatar_url TEXT,
  created_at TIMESTAMPTZ DEFAULT now(),
  updated_at TIMESTAMPTZ DEFAULT now()
);

-- Departments Table
CREATE TABLE IF NOT EXISTS departments (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL UNIQUE,
  description TEXT,
  icon TEXT,
  created_at TIMESTAMPTZ DEFAULT now()
);

-- Doctors Table
CREATE TABLE IF NOT EXISTS doctors (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL UNIQUE REFERENCES user_profiles(user_id) ON DELETE CASCADE,
  department_id UUID NOT NULL REFERENCES departments(id),
  specialization TEXT NOT NULL,
  license_number TEXT UNIQUE NOT NULL,
  bio TEXT,
  experience_years INTEGER DEFAULT 0,
  consultation_fee DECIMAL(10, 2) DEFAULT 500,
  availability_status BOOLEAN DEFAULT true,
  created_at TIMESTAMPTZ DEFAULT now(),
  updated_at TIMESTAMPTZ DEFAULT now()
);

-- Appointment Slots Table
CREATE TABLE IF NOT EXISTS appointment_slots (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  doctor_id UUID NOT NULL REFERENCES doctors(id) ON DELETE CASCADE,
  slot_date DATE NOT NULL,
  start_time TIME NOT NULL,
  end_time TIME NOT NULL,
  available_count INTEGER DEFAULT 1,
  created_at TIMESTAMPTZ DEFAULT now(),
  UNIQUE(doctor_id, slot_date, start_time)
);

-- Appointments Table
CREATE TABLE IF NOT EXISTS appointments (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  patient_id UUID NOT NULL REFERENCES user_profiles(user_id) ON DELETE CASCADE,
  doctor_id UUID NOT NULL REFERENCES doctors(user_id) ON DELETE CASCADE,
  appointment_date DATE NOT NULL,
  time_slot TIME NOT NULL,
  status appointment_status DEFAULT 'pending',
  reason_for_visit TEXT,
  notes TEXT,
  cancelled_by UUID REFERENCES user_profiles(user_id),
  cancellation_reason TEXT,
  created_at TIMESTAMPTZ DEFAULT now(),
  updated_at TIMESTAMPTZ DEFAULT now()
);

-- Lab Tests Table
CREATE TABLE IF NOT EXISTS lab_tests (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL UNIQUE,
  description TEXT,
  price DECIMAL(10, 2) NOT NULL,
  normal_range TEXT,
  unit TEXT,
  turnaround_days INTEGER DEFAULT 1,
  created_at TIMESTAMPTZ DEFAULT now()
);

-- Lab Results Table
CREATE TABLE IF NOT EXISTS lab_results (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  patient_id UUID NOT NULL REFERENCES user_profiles(user_id) ON DELETE CASCADE,
  lab_test_id UUID NOT NULL REFERENCES lab_tests(id),
  doctor_id UUID REFERENCES doctors(user_id) ON DELETE SET NULL,
  result_value TEXT,
  notes TEXT,
  status lab_result_status DEFAULT 'pending',
  test_date TIMESTAMPTZ DEFAULT now(),
  created_at TIMESTAMPTZ DEFAULT now()
);

-- Pharmacy Items Table
CREATE TABLE IF NOT EXISTS pharmacy_items (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL UNIQUE,
  description TEXT,
  price DECIMAL(10, 2) NOT NULL,
  stock_quantity INTEGER DEFAULT 0,
  dosage TEXT,
  manufacturer TEXT,
  expiry_date DATE,
  created_at TIMESTAMPTZ DEFAULT now(),
  updated_at TIMESTAMPTZ DEFAULT now()
);

-- Prescriptions Table
CREATE TABLE IF NOT EXISTS prescriptions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  doctor_id UUID NOT NULL REFERENCES doctors(user_id) ON DELETE CASCADE,
  patient_id UUID NOT NULL REFERENCES user_profiles(user_id) ON DELETE CASCADE,
  pharmacy_item_id UUID NOT NULL REFERENCES pharmacy_items(id),
  quantity INTEGER NOT NULL,
  dosage_instructions TEXT NOT NULL,
  duration_days INTEGER,
  prescribed_date TIMESTAMPTZ DEFAULT now(),
  created_at TIMESTAMPTZ DEFAULT now()
);

-- Billing Records Table
CREATE TABLE IF NOT EXISTS billing_records (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  patient_id UUID NOT NULL REFERENCES user_profiles(user_id) ON DELETE CASCADE,
  appointment_id UUID REFERENCES appointments(id) ON DELETE SET NULL,
  lab_result_id UUID REFERENCES lab_results(id) ON DELETE SET NULL,
  prescription_id UUID REFERENCES prescriptions(id) ON DELETE SET NULL,
  service_type TEXT NOT NULL,
  amount DECIMAL(10, 2) NOT NULL,
  status billing_status DEFAULT 'pending',
  stripe_payment_id TEXT,
  payment_date TIMESTAMPTZ,
  due_date DATE,
  created_at TIMESTAMPTZ DEFAULT now(),
  updated_at TIMESTAMPTZ DEFAULT now()
);

-- Emergency Contacts Table
CREATE TABLE IF NOT EXISTS emergency_contacts (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  patient_id UUID NOT NULL UNIQUE REFERENCES user_profiles(user_id) ON DELETE CASCADE,
  contact_name TEXT NOT NULL,
  relationship TEXT NOT NULL,
  phone TEXT NOT NULL,
  created_at TIMESTAMPTZ DEFAULT now(),
  updated_at TIMESTAMPTZ DEFAULT now()
);

-- Support Tickets Table
CREATE TABLE IF NOT EXISTS support_tickets (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES user_profiles(user_id) ON DELETE CASCADE,
  subject TEXT NOT NULL,
  description TEXT NOT NULL,
  status support_status DEFAULT 'open',
  assigned_to UUID REFERENCES user_profiles(user_id) ON DELETE SET NULL,
  created_at TIMESTAMPTZ DEFAULT now(),
  updated_at TIMESTAMPTZ DEFAULT now()
);

-- Create indexes for performance
CREATE INDEX idx_user_profiles_user_id ON user_profiles(user_id);
CREATE INDEX idx_user_profiles_role ON user_profiles(role);
CREATE INDEX idx_doctors_user_id ON doctors(user_id);
CREATE INDEX idx_doctors_department_id ON doctors(department_id);
CREATE INDEX idx_appointments_patient_id ON appointments(patient_id);
CREATE INDEX idx_appointments_doctor_id ON appointments(doctor_id);
CREATE INDEX idx_appointments_date ON appointments(appointment_date);
CREATE INDEX idx_lab_results_patient_id ON lab_results(patient_id);
CREATE INDEX idx_lab_results_status ON lab_results(status);
CREATE INDEX idx_prescriptions_patient_id ON prescriptions(patient_id);
CREATE INDEX idx_billing_patient_id ON billing_records(patient_id);
CREATE INDEX idx_billing_status ON billing_records(status);
CREATE INDEX idx_support_tickets_user_id ON support_tickets(user_id);
