/*
  # Row Level Security (RLS) Policies for MediVenture Pro

  ## Overview
  Implements comprehensive RLS policies ensuring:
  - Patients can only access their own data
  - Doctors can access their appointments and patient data they're assigned to
  - Staff/Admin can manage broader hospital operations
  - Public read access for departments and lab tests listings

  ## Security Principles
  1. All tables have RLS enabled by default
  2. RESTRICTIVE approach: deny by default, allow explicitly
  3. User role checked via user_profiles.role
  4. Ownership verified via user IDs
  5. Staff/Admin have elevated permissions
*/

-- Enable RLS on all tables
ALTER TABLE user_profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE doctors ENABLE ROW LEVEL SECURITY;
ALTER TABLE departments ENABLE ROW LEVEL SECURITY;
ALTER TABLE appointments ENABLE ROW LEVEL SECURITY;
ALTER TABLE appointment_slots ENABLE ROW LEVEL SECURITY;
ALTER TABLE lab_tests ENABLE ROW LEVEL SECURITY;
ALTER TABLE lab_results ENABLE ROW LEVEL SECURITY;
ALTER TABLE pharmacy_items ENABLE ROW LEVEL SECURITY;
ALTER TABLE prescriptions ENABLE ROW LEVEL SECURITY;
ALTER TABLE billing_records ENABLE ROW LEVEL SECURITY;
ALTER TABLE emergency_contacts ENABLE ROW LEVEL SECURITY;
ALTER TABLE support_tickets ENABLE ROW LEVEL SECURITY;

-- ============ USER PROFILES POLICIES ============

CREATE POLICY "Users can view own profile"
  ON user_profiles
  FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can view all profiles (needed for doctor/patient lookup)"
  ON user_profiles
  FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Users can update own profile"
  ON user_profiles
  FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id AND role = (SELECT role FROM user_profiles WHERE user_id = auth.uid()));

CREATE POLICY "Staff and admin can insert profiles"
  ON user_profiles
  FOR INSERT
  TO authenticated
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM user_profiles
      WHERE user_id = auth.uid()
      AND role IN ('staff', 'admin')
    )
  );

-- ============ DOCTORS POLICIES ============

CREATE POLICY "Anyone can view doctor listings"
  ON doctors
  FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Doctors can update own profile"
  ON doctors
  FOR UPDATE
  TO authenticated
  USING (user_id = auth.uid())
  WITH CHECK (user_id = auth.uid());

CREATE POLICY "Staff and admin can manage doctors"
  ON doctors
  FOR INSERT
  TO authenticated
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM user_profiles
      WHERE user_id = auth.uid()
      AND role IN ('staff', 'admin')
    )
  );

-- ============ DEPARTMENTS POLICIES ============

CREATE POLICY "Anyone can view departments"
  ON departments
  FOR SELECT
  TO anon, authenticated
  USING (true);

CREATE POLICY "Only staff and admin can manage departments"
  ON departments
  FOR ALL
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM user_profiles
      WHERE user_id = auth.uid()
      AND role IN ('staff', 'admin')
    )
  );

-- ============ APPOINTMENTS POLICIES ============

CREATE POLICY "Patients can view own appointments"
  ON appointments
  FOR SELECT
  TO authenticated
  USING (patient_id = auth.uid());

CREATE POLICY "Doctors can view their appointments"
  ON appointments
  FOR SELECT
  TO authenticated
  USING (
    doctor_id = auth.uid() OR
    EXISTS (
      SELECT 1 FROM user_profiles
      WHERE user_id = auth.uid()
      AND role IN ('staff', 'admin')
    )
  );

CREATE POLICY "Patients can create appointments"
  ON appointments
  FOR INSERT
  TO authenticated
  WITH CHECK (
    patient_id = auth.uid() AND
    EXISTS (
      SELECT 1 FROM user_profiles
      WHERE user_id = auth.uid()
      AND role = 'patient'
    )
  );

CREATE POLICY "Patients can update own appointments"
  ON appointments
  FOR UPDATE
  TO authenticated
  USING (patient_id = auth.uid())
  WITH CHECK (patient_id = auth.uid());

CREATE POLICY "Doctors and staff can update appointment status"
  ON appointments
  FOR UPDATE
  TO authenticated
  USING (
    doctor_id = auth.uid() OR
    EXISTS (
      SELECT 1 FROM user_profiles
      WHERE user_id = auth.uid()
      AND role IN ('staff', 'admin')
    )
  )
  WITH CHECK (
    doctor_id = auth.uid() OR
    EXISTS (
      SELECT 1 FROM user_profiles
      WHERE user_id = auth.uid()
      AND role IN ('staff', 'admin')
    )
  );

-- ============ APPOINTMENT SLOTS POLICIES ============

CREATE POLICY "Anyone can view appointment slots"
  ON appointment_slots
  FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Doctors can manage own slots"
  ON appointment_slots
  FOR ALL
  TO authenticated
  USING (
    doctor_id IN (
      SELECT id FROM doctors WHERE user_id = auth.uid()
    )
  );

CREATE POLICY "Staff and admin can manage slots"
  ON appointment_slots
  FOR ALL
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM user_profiles
      WHERE user_id = auth.uid()
      AND role IN ('staff', 'admin')
    )
  );

-- ============ LAB TESTS POLICIES ============

CREATE POLICY "Anyone can view lab test catalog"
  ON lab_tests
  FOR SELECT
  TO anon, authenticated
  USING (true);

CREATE POLICY "Only staff and admin can manage lab tests"
  ON lab_tests
  FOR ALL
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM user_profiles
      WHERE user_id = auth.uid()
      AND role IN ('staff', 'admin')
    )
  );

-- ============ LAB RESULTS POLICIES ============

CREATE POLICY "Patients can view own lab results"
  ON lab_results
  FOR SELECT
  TO authenticated
  USING (patient_id = auth.uid());

CREATE POLICY "Doctors can view patient lab results"
  ON lab_results
  FOR SELECT
  TO authenticated
  USING (
    doctor_id = auth.uid() OR
    EXISTS (
      SELECT 1 FROM user_profiles
      WHERE user_id = auth.uid()
      AND role IN ('staff', 'admin')
    )
  );

CREATE POLICY "Doctors and staff can create lab results"
  ON lab_results
  FOR INSERT
  TO authenticated
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM user_profiles
      WHERE user_id = auth.uid()
      AND role IN ('doctor', 'staff', 'admin')
    )
  );

CREATE POLICY "Doctors and staff can update lab results"
  ON lab_results
  FOR UPDATE
  TO authenticated
  USING (
    doctor_id = auth.uid() OR
    EXISTS (
      SELECT 1 FROM user_profiles
      WHERE user_id = auth.uid()
      AND role IN ('staff', 'admin')
    )
  )
  WITH CHECK (
    doctor_id = auth.uid() OR
    EXISTS (
      SELECT 1 FROM user_profiles
      WHERE user_id = auth.uid()
      AND role IN ('staff', 'admin')
    )
  );

-- ============ PHARMACY ITEMS POLICIES ============

CREATE POLICY "Anyone can view pharmacy items"
  ON pharmacy_items
  FOR SELECT
  TO anon, authenticated
  USING (true);

CREATE POLICY "Only staff and admin can manage pharmacy"
  ON pharmacy_items
  FOR ALL
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM user_profiles
      WHERE user_id = auth.uid()
      AND role IN ('staff', 'admin')
    )
  );

-- ============ PRESCRIPTIONS POLICIES ============

CREATE POLICY "Patients can view own prescriptions"
  ON prescriptions
  FOR SELECT
  TO authenticated
  USING (patient_id = auth.uid());

CREATE POLICY "Doctors can view patient prescriptions"
  ON prescriptions
  FOR SELECT
  TO authenticated
  USING (
    doctor_id = auth.uid() OR
    EXISTS (
      SELECT 1 FROM user_profiles
      WHERE user_id = auth.uid()
      AND role IN ('staff', 'admin')
    )
  );

CREATE POLICY "Doctors can create prescriptions"
  ON prescriptions
  FOR INSERT
  TO authenticated
  WITH CHECK (
    doctor_id = auth.uid() AND
    EXISTS (
      SELECT 1 FROM user_profiles
      WHERE user_id = auth.uid()
      AND role = 'doctor'
    )
  );

-- ============ BILLING POLICIES ============

CREATE POLICY "Patients can view own billing records"
  ON billing_records
  FOR SELECT
  TO authenticated
  USING (patient_id = auth.uid());

CREATE POLICY "Staff and admin can view all billing"
  ON billing_records
  FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM user_profiles
      WHERE user_id = auth.uid()
      AND role IN ('staff', 'admin')
    )
  );

CREATE POLICY "Staff and admin can create billing records"
  ON billing_records
  FOR INSERT
  TO authenticated
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM user_profiles
      WHERE user_id = auth.uid()
      AND role IN ('staff', 'admin')
    )
  );

CREATE POLICY "Patients and staff can update billing"
  ON billing_records
  FOR UPDATE
  TO authenticated
  USING (
    patient_id = auth.uid() OR
    EXISTS (
      SELECT 1 FROM user_profiles
      WHERE user_id = auth.uid()
      AND role IN ('staff', 'admin')
    )
  )
  WITH CHECK (
    patient_id = auth.uid() OR
    EXISTS (
      SELECT 1 FROM user_profiles
      WHERE user_id = auth.uid()
      AND role IN ('staff', 'admin')
    )
  );

-- ============ EMERGENCY CONTACTS POLICIES ============

CREATE POLICY "Patients can view own emergency contact"
  ON emergency_contacts
  FOR SELECT
  TO authenticated
  USING (patient_id = auth.uid());

CREATE POLICY "Patients can manage own emergency contact"
  ON emergency_contacts
  FOR ALL
  TO authenticated
  USING (patient_id = auth.uid())
  WITH CHECK (patient_id = auth.uid());

CREATE POLICY "Staff and admin can view emergency contacts"
  ON emergency_contacts
  FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM user_profiles
      WHERE user_id = auth.uid()
      AND role IN ('staff', 'admin')
    )
  );

-- ============ SUPPORT TICKETS POLICIES ============

CREATE POLICY "Users can view own support tickets"
  ON support_tickets
  FOR SELECT
  TO authenticated
  USING (user_id = auth.uid());

CREATE POLICY "Staff and admin can view all support tickets"
  ON support_tickets
  FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM user_profiles
      WHERE user_id = auth.uid()
      AND role IN ('staff', 'admin')
    )
  );

CREATE POLICY "Authenticated users can create support tickets"
  ON support_tickets
  FOR INSERT
  TO authenticated
  WITH CHECK (user_id = auth.uid());

CREATE POLICY "Users can update own tickets"
  ON support_tickets
  FOR UPDATE
  TO authenticated
  USING (user_id = auth.uid())
  WITH CHECK (user_id = auth.uid());

CREATE POLICY "Staff and admin can update all tickets"
  ON support_tickets
  FOR UPDATE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM user_profiles
      WHERE user_id = auth.uid()
      AND role IN ('staff', 'admin')
    )
  );
