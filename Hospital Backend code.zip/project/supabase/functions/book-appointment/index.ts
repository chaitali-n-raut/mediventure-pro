import "jsr:@supabase/functions-js/edge-runtime.d.ts";
import { createClient } from "npm:@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

interface BookAppointmentRequest {
  doctor_id: string;
  appointment_date: string;
  time_slot: string;
  reason_for_visit: string;
}

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, {
      status: 200,
      headers: corsHeaders,
    });
  }

  try {
    const authHeader = req.headers.get("Authorization");
    if (!authHeader) {
      return new Response(
        JSON.stringify({ error: "Missing authorization header" }),
        {
          status: 401,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        }
      );
    }

    const token = authHeader.replace("Bearer ", "");
    const supabase = createClient(
      Deno.env.get("SUPABASE_URL") ?? "",
      Deno.env.get("SUPABASE_ANON_KEY") ?? "",
      {
        global: {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        },
      }
    );

    const { data: userData, error: userError } = await supabase.auth.getUser();
    if (userError || !userData.user) {
      return new Response(
        JSON.stringify({ error: "Unauthorized" }),
        {
          status: 401,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        }
      );
    }

    const { doctor_id, appointment_date, time_slot, reason_for_visit }: BookAppointmentRequest = await req.json();

    if (!doctor_id || !appointment_date || !time_slot) {
      return new Response(
        JSON.stringify({ error: "Missing required fields" }),
        {
          status: 400,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        }
      );
    }

    const { data: appointment, error: appointmentError } = await supabase
      .from("appointments")
      .insert([
        {
          patient_id: userData.user.id,
          doctor_id,
          appointment_date,
          time_slot,
          reason_for_visit,
          status: "pending",
        },
      ])
      .select()
      .single();

    if (appointmentError) {
      return new Response(
        JSON.stringify({ error: appointmentError.message }),
        {
          status: 400,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        }
      );
    }

    const { error: billingError } = await supabase.from("billing_records").insert([
      {
        patient_id: userData.user.id,
        appointment_id: appointment.id,
        service_type: "appointment",
        amount: 500,
        status: "pending",
        due_date: new Date(appointment_date).toISOString().split('T')[0],
      },
    ]);

    if (billingError) {
      console.error("Billing creation error:", billingError);
    }

    return new Response(
      JSON.stringify({
        message: "Appointment booked successfully",
        appointment,
      }),
      {
        status: 200,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      }
    );
  } catch (error) {
    return new Response(
      JSON.stringify({ error: error.message }),
      {
        status: 500,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      }
    );
  }
});
