import "jsr:@supabase/functions-js/edge-runtime.d.ts";
import { createClient } from "npm:@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

interface CreatePrescriptionRequest {
  patient_id: string;
  pharmacy_item_id: string;
  quantity: number;
  dosage_instructions: string;
  duration_days: number;
}

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, {
      status: 200,
      headers: corsHeaders,
    });
  }

  try {
    const authHeader = req.headers.get("Authorization");
    if (!authHeader) {
      return new Response(
        JSON.stringify({ error: "Missing authorization header" }),
        {
          status: 401,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        }
      );
    }

    const token = authHeader.replace("Bearer ", "");
    const supabase = createClient(
      Deno.env.get("SUPABASE_URL") ?? "",
      Deno.env.get("SUPABASE_ANON_KEY") ?? "",
      {
        global: {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        },
      }
    );

    const { data: userData, error: userError } = await supabase.auth.getUser();
    if (userError || !userData.user) {
      return new Response(
        JSON.stringify({ error: "Unauthorized" }),
        {
          status: 401,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        }
      );
    }

    const { data: doctorData } = await supabase
      .from("doctors")
      .select("id")
      .eq("user_id", userData.user.id)
      .single();

    if (!doctorData) {
      return new Response(
        JSON.stringify({ error: "Only doctors can create prescriptions" }),
        {
          status: 403,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        }
      );
    }

    const { patient_id, pharmacy_item_id, quantity, dosage_instructions, duration_days }: CreatePrescriptionRequest = await req.json();

    if (!patient_id || !pharmacy_item_id || !quantity || !dosage_instructions) {
      return new Response(
        JSON.stringify({ error: "Missing required fields" }),
        {
          status: 400,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        }
      );
    }

    const { data: pharmItem } = await supabase
      .from("pharmacy_items")
      .select("price")
      .eq("id", pharmacy_item_id)
      .single();

    if (!pharmItem) {
      return new Response(
        JSON.stringify({ error: "Pharmacy item not found" }),
        {
          status: 404,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        }
      );
    }

    const { data: prescription, error: prescriptionError } = await supabase
      .from("prescriptions")
      .insert([
        {
          doctor_id: userData.user.id,
          patient_id,
          pharmacy_item_id,
          quantity,
          dosage_instructions,
          duration_days,
        },
      ])
      .select()
      .single();

    if (prescriptionError) {
      return new Response(
        JSON.stringify({ error: prescriptionError.message }),
        {
          status: 400,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        }
      );
    }

    const totalAmount = (pharmItem.price ?? 0) * quantity;
    await supabase.from("billing_records").insert([
      {
        patient_id,
        prescription_id: prescription.id,
        service_type: "prescription",
        amount: totalAmount,
        status: "pending",
      },
    ]);

    return new Response(
      JSON.stringify({
        message: "Prescription created successfully",
        prescription,
      }),
      {
        status: 200,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      }
    );
  } catch (error) {
    return new Response(
      JSON.stringify({ error: error.message }),
      {
        status: 500,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      }
    );
  }
});
