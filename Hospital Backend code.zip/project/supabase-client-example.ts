// Example: How to integrate Supabase client in your React app
// Copy this pattern to your src/lib/supabase.ts or similar

import { createClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

export const supabase = createClient(supabaseUrl, supabaseAnonKey);

// ============ AUTHENTICATION ============

export const authService = {
  async signup(email: string, password: string, fullName: string, phone: string, role: 'patient' | 'doctor' | 'staff') {
    const apiUrl = `${supabaseUrl}/functions/v1/signup`;
    const response = await fetch(apiUrl, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        email,
        password,
        full_name: fullName,
        phone,
        role,
      }),
    });
    return response.json();
  },

  async signupDoctor(
    email: string,
    password: string,
    fullName: string,
    phone: string,
    specialization: string,
    licenseNumber: string
  ) {
    const apiUrl = `${supabaseUrl}/functions/v1/signup`;
    const response = await fetch(apiUrl, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        email,
        password,
        full_name: fullName,
        phone,
        role: 'doctor',
        specialization,
        license_number: licenseNumber,
      }),
    });
    return response.json();
  },

  async signin(email: string, password: string) {
    const { data, error } = await supabase.auth.signInWithPassword({
      email,
      password,
    });
    return { data, error };
  },

  async signout() {
    const { error } = await supabase.auth.signOut();
    return { error };
  },

  async getCurrentUser() {
    const { data: { user }, error } = await supabase.auth.getUser();
    return { user, error };
  },

  async getUserProfile(userId: string) {
    const { data, error } = await supabase
      .from('user_profiles')
      .select('id, role, full_name, phone, avatar_url')
      .eq('user_id', userId)
      .maybeSingle();
    return { data, error };
  },

  onAuthStateChange(callback: (event: string, session: any) => void) {
    return supabase.auth.onAuthStateChange(callback);
  },
};

// ============ DEPARTMENTS ============

export const departmentService = {
  async getAll() {
    const { data, error } = await supabase
      .from('departments')
      .select('id, name, description, icon')
      .order('name');
    return { data, error };
  },

  async getById(id: string) {
    const { data, error } = await supabase
      .from('departments')
      .select('id, name, description, icon')
      .eq('id', id)
      .maybeSingle();
    return { data, error };
  },
};

// ============ DOCTORS ============

export const doctorService = {
  async getAll() {
    const { data, error } = await supabase
      .from('doctors')
      .select(`
        id,
        user_id,
        specialization,
        consultation_fee,
        availability_status,
        user_profiles(full_name, phone, avatar_url)
      `)
      .eq('availability_status', true)
      .order('id');
    return { data, error };
  },

  async getByDepartment(departmentId: string) {
    const { data, error } = await supabase
      .from('doctors')
      .select(`
        id,
        user_id,
        specialization,
        consultation_fee,
        availability_status,
        user_profiles(full_name, phone, avatar_url)
      `)
      .eq('department_id', departmentId)
      .eq('availability_status', true)
      .order('id');
    return { data, error };
  },

  async getById(doctorId: string) {
    const { data, error } = await supabase
      .from('doctors')
      .select(`
        id,
        user_id,
        department_id,
        specialization,
        bio,
        experience_years,
        consultation_fee,
        availability_status,
        user_profiles(full_name, phone, avatar_url)
      `)
      .eq('id', doctorId)
      .maybeSingle();
    return { data, error };
  },

  async getAvailableSlots(doctorId: string, date: string) {
    const { data, error } = await supabase
      .from('appointment_slots')
      .select('id, slot_date, start_time, end_time, available_count')
      .eq('doctor_id', doctorId)
      .eq('slot_date', date)
      .gt('available_count', 0);
    return { data, error };
  },
};

// ============ APPOINTMENTS ============

export const appointmentService = {
  async bookAppointment(
    doctorId: string,
    appointmentDate: string,
    timeSlot: string,
    reasonForVisit: string
  ) {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) throw new Error('User not authenticated');

    const apiUrl = `${supabaseUrl}/functions/v1/book-appointment`;
    const response = await fetch(apiUrl, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${(await supabase.auth.getSession()).data.session?.access_token}`,
      },
      body: JSON.stringify({
        doctor_id: doctorId,
        appointment_date: appointmentDate,
        time_slot: timeSlot,
        reason_for_visit: reasonForVisit,
      }),
    });
    return response.json();
  },

  async getPatientAppointments(patientId: string) {
    const { data, error } = await supabase
      .from('appointments')
      .select(`
        id,
        appointment_date,
        time_slot,
        status,
        reason_for_visit,
        doctors(user_profiles(full_name), specialization)
      `)
      .eq('patient_id', patientId)
      .order('appointment_date', { ascending: false });
    return { data, error };
  },

  async getDoctorAppointments(doctorUserId: string) {
    const { data, error } = await supabase
      .from('appointments')
      .select(`
        id,
        appointment_date,
        time_slot,
        status,
        reason_for_visit,
        user_profiles(full_name, phone)
      `)
      .eq('doctor_id', doctorUserId)
      .order('appointment_date', { ascending: false });
    return { data, error };
  },

  async updateAppointmentStatus(appointmentId: string, status: 'confirmed' | 'completed' | 'cancelled') {
    const { data, error } = await supabase
      .from('appointments')
      .update({ status, updated_at: new Date().toISOString() })
      .eq('id', appointmentId)
      .select()
      .maybeSingle();
    return { data, error };
  },

  async cancelAppointment(appointmentId: string, reason: string) {
    const { data, error } = await supabase
      .from('appointments')
      .update({
        status: 'cancelled',
        cancellation_reason: reason,
        updated_at: new Date().toISOString(),
      })
      .eq('id', appointmentId)
      .select()
      .maybeSingle();
    return { data, error };
  },
};

// ============ LAB TESTS ============

export const labTestService = {
  async getAll() {
    const { data, error } = await supabase
      .from('lab_tests')
      .select('id, name, description, price, turnaround_days')
      .order('name');
    return { data, error };
  },

  async getById(testId: string) {
    const { data, error } = await supabase
      .from('lab_tests')
      .select('id, name, description, price, normal_range, unit, turnaround_days')
      .eq('id', testId)
      .maybeSingle();
    return { data, error };
  },

  async orderTest(
    patientId: string,
    labTestId: string,
    doctorId?: string
  ) {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) throw new Error('User not authenticated');

    const apiUrl = `${supabaseUrl}/functions/v1/create-lab-order`;
    const response = await fetch(apiUrl, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${(await supabase.auth.getSession()).data.session?.access_token}`,
      },
      body: JSON.stringify({
        patient_id: patientId,
        lab_test_id: labTestId,
        doctor_id: doctorId,
      }),
    });
    return response.json();
  },

  async getPatientResults(patientId: string) {
    const { data, error } = await supabase
      .from('lab_results')
      .select(`
        id,
        status,
        test_date,
        result_value,
        lab_tests(name, description, normal_range, unit)
      `)
      .eq('patient_id', patientId)
      .order('test_date', { ascending: false });
    return { data, error };
  },
};

// ============ PHARMACY ============

export const pharmacyService = {
  async getAll() {
    const { data, error } = await supabase
      .from('pharmacy_items')
      .select('id, name, description, price, stock_quantity, dosage')
      .gt('stock_quantity', 0)
      .order('name');
    return { data, error };
  },

  async getById(itemId: string) {
    const { data, error } = await supabase
      .from('pharmacy_items')
      .select('id, name, description, price, stock_quantity, dosage, manufacturer, expiry_date')
      .eq('id', itemId)
      .maybeSingle();
    return { data, error };
  },

  async getPatientPrescriptions(patientId: string) {
    const { data, error } = await supabase
      .from('prescriptions')
      .select(`
        id,
        prescribed_date,
        quantity,
        dosage_instructions,
        duration_days,
        pharmacy_items(name, dosage, price),
        user_profiles(full_name)
      `)
      .eq('patient_id', patientId)
      .order('prescribed_date', { ascending: false });
    return { data, error };
  },
};

// ============ BILLING ============

export const billingService = {
  async getPatientBilling(patientId: string) {
    const { data, error } = await supabase
      .from('billing_records')
      .select(`
        id,
        service_type,
        amount,
        status,
        created_at,
        due_date
      `)
      .eq('patient_id', patientId)
      .order('created_at', { ascending: false });
    return { data, error };
  },

  async updateBillingStatus(billingId: string, status: 'pending' | 'paid' | 'failed') {
    const { data, error } = await supabase
      .from('billing_records')
      .update({
        status,
        updated_at: new Date().toISOString(),
      })
      .eq('id', billingId)
      .select()
      .maybeSingle();
    return { data, error };
  },

  async recordPayment(billingId: string, stripePaymentId: string) {
    const { data, error } = await supabase
      .from('billing_records')
      .update({
        status: 'paid',
        stripe_payment_id: stripePaymentId,
        payment_date: new Date().toISOString(),
        updated_at: new Date().toISOString(),
      })
      .eq('id', billingId)
      .select()
      .maybeSingle();
    return { data, error };
  },
};

// ============ EMERGENCY CONTACTS ============

export const emergencyContactService = {
  async get(patientId: string) {
    const { data, error } = await supabase
      .from('emergency_contacts')
      .select('id, contact_name, relationship, phone')
      .eq('patient_id', patientId)
      .maybeSingle();
    return { data, error };
  },

  async create(patientId: string, contactName: string, relationship: string, phone: string) {
    const { data, error } = await supabase
      .from('emergency_contacts')
      .insert({
        patient_id: patientId,
        contact_name: contactName,
        relationship,
        phone,
      })
      .select()
      .maybeSingle();
    return { data, error };
  },

  async update(patientId: string, contactName: string, relationship: string, phone: string) {
    const { data, error } = await supabase
      .from('emergency_contacts')
      .update({
        contact_name: contactName,
        relationship,
        phone,
      })
      .eq('patient_id', patientId)
      .select()
      .maybeSingle();
    return { data, error };
  },
};

// ============ SUPPORT TICKETS ============

export const supportTicketService = {
  async create(subject: string, description: string) {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) throw new Error('User not authenticated');

    const { data, error } = await supabase
      .from('support_tickets')
      .insert({
        user_id: user.id,
        subject,
        description,
        status: 'open',
      })
      .select()
      .maybeSingle();
    return { data, error };
  },

  async getUserTickets(userId: string) {
    const { data, error } = await supabase
      .from('support_tickets')
      .select('id, subject, description, status, created_at, updated_at')
      .eq('user_id', userId)
      .order('created_at', { ascending: false });
    return { data, error };
  },
};

export default supabase;
