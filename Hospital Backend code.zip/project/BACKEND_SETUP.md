# MediVenture Pro - Backend Setup Guide

## Overview

Your healthcare management system backend is now powered by Supabase with:
- Complete PostgreSQL database schema
- Row-level security (RLS) for data protection
- Authentication system with role-based access
- Pre-built Edge Functions for key operations
- Seed data (departments, lab tests, pharmacy items)

## Database Structure

### Core Tables

**user_profiles** - Extended user information
- Stores user role (patient, doctor, staff, admin)
- Full name, phone, avatar URL
- Links to Supabase auth.users

**doctors** - Doctor-specific information
- Specialization, license number, bio
- Department association
- Consultation fees and availability

**departments** - Medical departments
- Cardiology, Neurology, Orthopedics, etc.
- Pre-populated with 8 departments

**appointments** - Patient-doctor bookings
- Status tracking (pending, confirmed, completed, cancelled)
- Date, time, reason for visit
- Linked to billing

**lab_tests** - Laboratory tests catalog
- 10 common tests pre-populated
- Pricing and normal ranges

**lab_results** - Patient test results
- Status tracking (pending, completed)
- Links patient, doctor, and lab test

**pharmacy_items** - Medication catalog
- 10 sample medications pre-populated
- Stock, dosage, expiry tracking

**prescriptions** - Doctor prescriptions
- Links doctor, patient, medication
- Quantity and dosage instructions

**billing_records** - Payment tracking
- Service type, amount, status
- Stripe integration ready
- Auto-created for appointments and services

**emergency_contacts** - Emergency info
- Patient's emergency contact details

**support_tickets** - Customer support
- Status tracking and assignment

## Authentication Setup

### User Roles

- **patient** - Can book appointments, view own records
- **doctor** - Can manage appointments, write prescriptions, add results
- **staff** - Can manage departments, lab tests, pharmacy items
- **admin** - Full system access

### Signup via Edge Function

Your frontend should call the `/signup` Edge Function:

```typescript
const response = await fetch(
  `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/signup`,
  {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      email: 'user@example.com',
      password: 'securePassword',
      full_name: 'John Doe',
      phone: '1234567890',
      role: 'patient', // or 'doctor', 'staff'
      specialization: 'Cardiology', // if doctor
      license_number: 'DL123456', // if doctor
    }),
  }
);
```

### Standard Supabase Auth

Use the standard Supabase auth for login/logout:

```typescript
import { createClient } from '@supabase/supabase-js';

const supabase = createClient(
  import.meta.env.VITE_SUPABASE_URL,
  import.meta.env.VITE_SUPABASE_ANON_KEY
);

// Sign in
const { data, error } = await supabase.auth.signInWithPassword({
  email: 'user@example.com',
  password: 'password',
});

// Sign out
await supabase.auth.signOut();

// Get current user
const { data: { user } } = await supabase.auth.getUser();
```

## Edge Functions

### 1. Signup Function

**Endpoint:** `POST /functions/v1/signup`

Creates user account with profile and optional doctor info.

**Request:**
```json
{
  "email": "doctor@hospital.com",
  "password": "securePassword",
  "full_name": "Dr. Sarah",
  "phone": "9876543210",
  "role": "doctor",
  "specialization": "Cardiology",
  "license_number": "DL123456"
}
```

**Response:**
```json
{
  "message": "User created successfully",
  "user": {
    "id": "user-uuid",
    "email": "doctor@hospital.com",
    "role": "doctor"
  }
}
```

### 2. Book Appointment Function

**Endpoint:** `POST /functions/v1/book-appointment`

Books appointment and creates billing record.

**Headers:** Requires Authorization Bearer token

**Request:**
```json
{
  "doctor_id": "doctor-user-id",
  "appointment_date": "2024-12-15",
  "time_slot": "14:30",
  "reason_for_visit": "Regular checkup"
}
```

**Response:**
```json
{
  "message": "Appointment booked successfully",
  "appointment": {
    "id": "appointment-uuid",
    "patient_id": "patient-uuid",
    "doctor_id": "doctor-uuid",
    "appointment_date": "2024-12-15",
    "time_slot": "14:30",
    "status": "pending"
  }
}
```

### 3. Create Prescription Function

**Endpoint:** `POST /functions/v1/create-prescription`

Creates doctor prescription and auto-generates billing.

**Headers:** Requires Authorization Bearer token (Doctor only)

**Request:**
```json
{
  "patient_id": "patient-uuid",
  "pharmacy_item_id": "item-uuid",
  "quantity": 2,
  "dosage_instructions": "One tablet twice daily after meals",
  "duration_days": 7
}
```

**Response:**
```json
{
  "message": "Prescription created successfully",
  "prescription": {
    "id": "prescription-uuid",
    "doctor_id": "doctor-uuid",
    "patient_id": "patient-uuid",
    "quantity": 2,
    "dosage_instructions": "One tablet twice daily after meals"
  }
}
```

### 4. Create Lab Order Function

**Endpoint:** `POST /functions/v1/create-lab-order`

Creates lab test order and billing.

**Headers:** Requires Authorization Bearer token

**Request:**
```json
{
  "patient_id": "patient-uuid",
  "lab_test_id": "test-uuid",
  "doctor_id": "doctor-uuid"
}
```

**Response:**
```json
{
  "message": "Lab test order created successfully",
  "labResult": {
    "id": "lab-result-uuid",
    "patient_id": "patient-uuid",
    "status": "pending"
  }
}
```

## Frontend Integration Examples

### Initialize Supabase Client

```typescript
// src/lib/supabase.ts
import { createClient } from '@supabase/supabase-js';

export const supabase = createClient(
  import.meta.env.VITE_SUPABASE_URL,
  import.meta.env.VITE_SUPABASE_ANON_KEY
);
```

### Query Departments

```typescript
const { data: departments } = await supabase
  .from('departments')
  .select('id, name, description, icon');
```

### Query Doctors by Department

```typescript
const { data: doctors } = await supabase
  .from('doctors')
  .select('id, user_id, specialization, consultation_fee, user_profiles(full_name)')
  .eq('department_id', departmentId)
  .eq('availability_status', true);
```

### Get Patient's Appointments

```typescript
const { data: appointments } = await supabase
  .from('appointments')
  .select(`
    id,
    appointment_date,
    time_slot,
    status,
    doctors(user_profiles(full_name))
  `)
  .eq('patient_id', patientId)
  .order('appointment_date', { ascending: false });
```

### Get Lab Tests Catalog

```typescript
const { data: labTests } = await supabase
  .from('lab_tests')
  .select('id, name, description, price, turnaround_days')
  .order('name');
```

### Fetch User Profile with Role

```typescript
const { data: { user } } = await supabase.auth.getUser();

const { data: profile } = await supabase
  .from('user_profiles')
  .select('role, full_name, phone, avatar_url')
  .eq('user_id', user.id)
  .single();
```

### Listen to Real-time Changes (Optional)

```typescript
// Listen for appointment updates
supabase
  .channel('appointments')
  .on(
    'postgres_changes',
    {
      event: 'UPDATE',
      schema: 'public',
      table: 'appointments',
    },
    (payload) => {
      console.log('Appointment updated:', payload.new);
    }
  )
  .subscribe();
```

## Security Notes

1. **Row Level Security (RLS)** - All data is protected by RLS policies
   - Patients can only view their own data
   - Doctors can view their appointments
   - Staff/Admin have appropriate access levels

2. **Authentication** - All sensitive operations require JWT tokens

3. **Environment Variables** - Supabase automatically manages credentials in `.env`

## Testing the Backend

### 1. Create Test User (Patient)
```bash
curl -X POST https://your-project.supabase.co/functions/v1/signup \
  -H "Content-Type: application/json" \
  -d '{
    "email": "patient@example.com",
    "password": "TestPass123!",
    "full_name": "John Patient",
    "phone": "1234567890",
    "role": "patient"
  }'
```

### 2. Create Test Doctor
```bash
curl -X POST https://your-project.supabase.co/functions/v1/signup \
  -H "Content-Type: application/json" \
  -d '{
    "email": "doctor@example.com",
    "password": "TestPass123!",
    "full_name": "Dr. Sarah",
    "phone": "9876543210",
    "role": "doctor",
    "specialization": "Cardiology",
    "license_number": "DL123456"
  }'
```

### 3. Query Available Departments
```bash
curl https://your-project.supabase.co/rest/v1/departments \
  -H "Authorization: Bearer YOUR_ANON_KEY" \
  -H "apikey: YOUR_ANON_KEY"
```

## What's Included

### Database
- ✅ 12 core tables with proper relationships
- ✅ ENUM types for status tracking
- ✅ Indexes for performance optimization
- ✅ Foreign key constraints for data integrity

### Security
- ✅ Row Level Security on all tables
- ✅ Role-based access control policies
- ✅ Secure data isolation by user/role
- ✅ Authentication via Supabase Auth

### Edge Functions
- ✅ User signup with role assignment
- ✅ Appointment booking with auto-billing
- ✅ Prescription creation
- ✅ Lab order creation

### Seed Data
- ✅ 8 Medical departments
- ✅ 10 Lab tests with pricing
- ✅ 10 Pharmacy items with stock

## Next Steps

1. **Connect Your Frontend** - Update your React app to use Supabase client
2. **Implement Payment** - Integrate Stripe for billing (billing_records table ready)
3. **Add More Features** - Create additional edge functions as needed
4. **Deploy** - Deploy your frontend with the Supabase backend

## Troubleshooting

**Issue: "Permission denied" errors**
- Check that RLS policies allow your user role
- Verify user is authenticated with valid token

**Issue: Edge function returns 401**
- Ensure Authorization header is included
- Verify JWT token is valid and not expired

**Issue: Data not appearing**
- Check RLS policies match your query
- Verify user role is correctly set in user_profiles
- Confirm foreign key relationships are correct

## Support

For more info:
- Supabase Docs: https://supabase.com/docs
- Database Schema: Check your Supabase dashboard
- API Reference: Use Supabase REST API docs
